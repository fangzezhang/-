<template>
#[[$END$]]#
</template>

<script setup>
import { defineComponent } from 'vue';

#set($capitalizedFilename = $NAME.substring(0,1).toUpperCase() + $NAME.substring(1))
export default defineComponent({
  name: '$capitalizedFilename',
});
</script>

<style>
</style>
