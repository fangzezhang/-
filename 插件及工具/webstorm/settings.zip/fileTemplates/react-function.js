import React, {useState} from 'react';

#set($capitalizedFilename = $NAME.substring(0,1).toUpperCase() + $NAME.substring(1))
export default function $capitalizedFilename() {
  const [count, setCount] = useState(0);

  return (
    <div>
      <p>count: {count}</p>
      <button onClick={() => {setCount(count + 1)}}> click</button>
    </div>
  );
}
