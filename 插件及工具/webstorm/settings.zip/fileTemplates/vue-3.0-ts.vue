<template>
#[[$END$]]#
</template>

<script lang="ts">
import { Options, Vue } from 'vue-class-component';

@Options({})
#set($capitalizedFilename = $NAME.substring(0,1).toUpperCase() + $NAME.substring(1))
export default class $capitalizedFilename extends Vue {

}
</script>

<style lang="scss" scoped>

</style>