import React, {Component} from 'react';

#set($capitalizedFilename = $NAME.substring(0,1).toUpperCase() + $NAME.substring(1))
export default class $capitalizedFilename extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <div>
        <p></p>
      </div>
    );
  }
}
