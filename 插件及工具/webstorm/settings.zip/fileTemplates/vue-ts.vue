<template>
#[[$END$]]#
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

@Component
#set($capitalizedFilename = $NAME.substring(0,1).toUpperCase() + $NAME.substring(1))
export default class $capitalizedFilename extends Vue {

}
</script>

<style lang="less" scoped>

</style>