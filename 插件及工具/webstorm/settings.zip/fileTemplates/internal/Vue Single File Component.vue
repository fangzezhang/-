<template>
#[[$END$]]#
</template>

<script>
export default {
name: "${COMPONENT_NAME}",
data() {
return {}
}
}
</script>

<style scoped>

</style>